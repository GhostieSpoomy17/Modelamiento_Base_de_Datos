-- Generado por Oracle SQL Developer Data Modeler 24.3.1.351.0831
--   en:        2026-09-14 22:41:32 CLST
--   sitio:      Oracle Database 21c
--   tipo:      Oracle Database 21c



-- predefined type, no DDL - MDSYS.SDO_GEOMETRY

-- predefined type, no DDL - XMLTYPE

CREATE TABLE boleta 
    ( 
     numero_boleta NUMBER (10)  NOT NULL , 
     fecha_boleta  DATE  NOT NULL , 
     monto_total   NUMBER (10)  NOT NULL , 
     id_cliente    NUMBER (10)  NOT NULL 
    ) 
    LOGGING 
;

ALTER TABLE boleta 
    ADD CONSTRAINT boleta_pk PRIMARY KEY ( numero_boleta ) ;

CREATE TABLE categoria 
    ( 
     cod_categoria    NUMBER (4)  NOT NULL , 
     nombre_categoria VARCHAR2 (50)  NOT NULL 
    ) 
    LOGGING 
;

ALTER TABLE categoria 
    ADD CONSTRAINT categoria_pk PRIMARY KEY ( cod_categoria ) ;

CREATE TABLE cliente 
    ( 
     id_cliente      NUMBER (10)  NOT NULL , 
     nombre_completo VARCHAR2 (100)  NOT NULL , 
     telefono        VARCHAR2 (15)  NOT NULL , 
     cod_comuna      NUMBER (3)  NOT NULL 
    ) 
    LOGGING 
;

ALTER TABLE cliente 
    ADD CONSTRAINT cliente_pk PRIMARY KEY ( id_cliente ) ;

CREATE TABLE comuna 
    ( 
     cod_comuna    NUMBER (3)  NOT NULL , 
     nombre_comuna VARCHAR2 (50)  NOT NULL , 
     cod_region    NUMBER (2)  NOT NULL 
    ) 
    LOGGING 
;

ALTER TABLE comuna 
    ADD CONSTRAINT comuna_pk PRIMARY KEY ( cod_comuna ) ;

CREATE TABLE detalle_boleta 
    ( 
     numero_boleta   NUMBER (10)  NOT NULL , 
     id_producto     NUMBER (10)  NOT NULL , 
     cantidad        NUMBER (5)  NOT NULL , 
     precio_unitario NUMBER (10)  NOT NULL , 
     subtotal        NUMBER (10)  NOT NULL 
    ) 
    LOGGING 
;

ALTER TABLE detalle_boleta 
    ADD CONSTRAINT detalle_boleta_pk PRIMARY KEY ( numero_boleta, id_producto ) ;

CREATE TABLE marca 
    ( 
     cod_marca    NUMBER (5)  NOT NULL , 
     nombre_marca VARCHAR2 (50)  NOT NULL 
    ) 
    LOGGING 
;

ALTER TABLE marca 
    ADD CONSTRAINT marca_pk PRIMARY KEY ( cod_marca ) ;

CREATE TABLE modelo 
    ( 
     cod_marca     NUMBER (5)  NOT NULL , 
     cod_modelo    NUMBER (6)  NOT NULL , 
     nombre_modelo VARCHAR2 (50)  NOT NULL 
    ) 
    LOGGING 
;

ALTER TABLE modelo 
    ADD CONSTRAINT modelo_pk PRIMARY KEY ( cod_marca, cod_modelo ) ;

CREATE TABLE producto 
    ( 
     id_producto       NUMBER (10)  NOT NULL , 
     nombre_producto   VARCHAR2 (100)  NOT NULL , 
     descripcion       VARCHAR2 (500)  NOT NULL , 
     fecha_vencimiento DATE , 
     monto_venta       NUMBER (10)  NOT NULL , 
     sigla_sucursal    VARCHAR2 (5)  NOT NULL , 
     cod_categoria     NUMBER (4)  NOT NULL , 
     cod_marca         NUMBER (5)  NOT NULL , 
     cod_modelo        NUMBER (6)  NOT NULL 
    ) 
    LOGGING 
;

ALTER TABLE producto 
    ADD CONSTRAINT producto_pk PRIMARY KEY ( id_producto ) ;

CREATE TABLE producto_proveedor 
    ( 
     id_producto   NUMBER (10)  NOT NULL , 
     rut_proveedor NUMBER (9)  NOT NULL 
    ) 
    LOGGING 
;

ALTER TABLE producto_proveedor 
    ADD CONSTRAINT prod_prov_pk PRIMARY KEY ( id_producto, rut_proveedor ) ;

CREATE TABLE proveedor 
    ( 
     rut_proveedor   NUMBER (9)  NOT NULL , 
     dv_proveedor    VARCHAR2 (1)  NOT NULL , 
     fono_proveedor  VARCHAR2 (15)  NOT NULL , 
     email_proveedor VARCHAR2 (100)  NOT NULL , 
     calle_direccion VARCHAR2 (100)  NOT NULL , 
     num_calle       NUMBER (6)  NOT NULL , 
     codpostal       VARCHAR2 (10) , 
     tipo_proveedor  VARCHAR2 (1)  NOT NULL 
    ) 
    LOGGING 
;

ALTER TABLE proveedor 
    ADD CONSTRAINT proveedor_tipo_ck 
    CHECK (tipo_proveedor IN ('E','P'))
;
ALTER TABLE proveedor 
    ADD CONSTRAINT proveedor_pk PRIMARY KEY ( rut_proveedor ) ;

CREATE TABLE proveedor_empresa 
    ( 
     rut_proveedor NUMBER (9)  NOT NULL , 
     razon_social  VARCHAR2 (100)  NOT NULL , 
     website       VARCHAR2 (150) 
    ) 
    LOGGING 
;

ALTER TABLE proveedor_empresa 
    ADD CONSTRAINT prov_empresa_pk PRIMARY KEY ( rut_proveedor ) ;

CREATE TABLE proveedor_persona 
    ( 
     rut_proveedor NUMBER (9)  NOT NULL , 
     nombres       VARCHAR2 (50)  NOT NULL , 
     apellidos     VARCHAR2 (50)  NOT NULL 
    ) 
    LOGGING 
;

ALTER TABLE proveedor_persona 
    ADD CONSTRAINT prov_persona_pk PRIMARY KEY ( rut_proveedor ) ;

CREATE TABLE sucursal 
    ( 
     sigla_sucursal  VARCHAR2 (5)  NOT NULL , 
     nombre_sucursal VARCHAR2 (50)  NOT NULL , 
     cod_comuna      NUMBER (3)  NOT NULL 
    ) 
    LOGGING 
;

ALTER TABLE sucursal 
    ADD CONSTRAINT sucursal_pk PRIMARY KEY ( sigla_sucursal ) ;

ALTER TABLE boleta 
    ADD CONSTRAINT boleta_cliente_fk FOREIGN KEY 
    ( 
     id_cliente
    ) 
    REFERENCES cliente 
    ( 
     id_cliente
    ) 
    NOT DEFERRABLE 
;

ALTER TABLE cliente 
    ADD CONSTRAINT cliente_comuna_fk FOREIGN KEY 
    ( 
     cod_comuna
    ) 
    REFERENCES comuna 
    ( 
     cod_comuna
    ) 
    NOT DEFERRABLE 
;

ALTER TABLE detalle_boleta 
    ADD CONSTRAINT detalle_boleta_fk FOREIGN KEY 
    ( 
     numero_boleta
    ) 
    REFERENCES boleta 
    ( 
     numero_boleta
    ) 
    NOT DEFERRABLE 
;

ALTER TABLE detalle_boleta 
    ADD CONSTRAINT detalle_producto_fk FOREIGN KEY 
    ( 
     id_producto
    ) 
    REFERENCES producto 
    ( 
     id_producto
    ) 
    NOT DEFERRABLE 
;

ALTER TABLE modelo 
    ADD CONSTRAINT modelo_marca_fk FOREIGN KEY 
    ( 
     cod_marca
    ) 
    REFERENCES marca 
    ( 
     cod_marca
    ) 
    NOT DEFERRABLE 
;

ALTER TABLE producto_proveedor 
    ADD CONSTRAINT prod_prov_producto_fk FOREIGN KEY 
    ( 
     id_producto
    ) 
    REFERENCES producto 
    ( 
     id_producto
    ) 
    NOT DEFERRABLE 
;

ALTER TABLE producto_proveedor 
    ADD CONSTRAINT prod_prov_proveedor_fk FOREIGN KEY 
    ( 
     rut_proveedor
    ) 
    REFERENCES proveedor 
    ( 
     rut_proveedor
    ) 
    NOT DEFERRABLE 
;

ALTER TABLE producto 
    ADD CONSTRAINT producto_categoria_fk FOREIGN KEY 
    ( 
     cod_categoria
    ) 
    REFERENCES categoria 
    ( 
     cod_categoria
    ) 
    NOT DEFERRABLE 
;

ALTER TABLE producto 
    ADD CONSTRAINT producto_modelo_fk FOREIGN KEY 
    ( 
     cod_marca,
     cod_modelo
    ) 
    REFERENCES modelo 
    ( 
     cod_marca,
     cod_modelo
    ) 
    NOT DEFERRABLE 
;

ALTER TABLE producto 
    ADD CONSTRAINT producto_sucursal_fk FOREIGN KEY 
    ( 
     sigla_sucursal
    ) 
    REFERENCES sucursal 
    ( 
     sigla_sucursal
    ) 
    NOT DEFERRABLE 
;

ALTER TABLE proveedor_empresa 
    ADD CONSTRAINT prov_empresa_fk FOREIGN KEY 
    ( 
     rut_proveedor
    ) 
    REFERENCES proveedor 
    ( 
     rut_proveedor
    ) 
    NOT DEFERRABLE 
;

ALTER TABLE proveedor_persona 
    ADD CONSTRAINT prov_persona_fk FOREIGN KEY 
    ( 
     rut_proveedor
    ) 
    REFERENCES proveedor 
    ( 
     rut_proveedor
    ) 
    NOT DEFERRABLE 
;

ALTER TABLE sucursal 
    ADD CONSTRAINT sucursal_comuna_fk FOREIGN KEY 
    ( 
     cod_comuna
    ) 
    REFERENCES comuna 
    ( 
     cod_comuna
    ) 
    NOT DEFERRABLE 
;



-- Informe de Resumen de Oracle SQL Developer Data Modeler: 
-- 
-- CREATE TABLE                            13
-- CREATE INDEX                             0
-- ALTER TABLE                             27
-- CREATE VIEW                              0
-- ALTER VIEW                               0
-- CREATE PACKAGE                           0
-- CREATE PACKAGE BODY                      0
-- CREATE PROCEDURE                         0
-- CREATE FUNCTION                          0
-- CREATE TRIGGER                           0
-- ALTER TRIGGER                            0
-- CREATE COLLECTION TYPE                   0
-- CREATE STRUCTURED TYPE                   0
-- CREATE STRUCTURED TYPE BODY              0
-- CREATE CLUSTER                           0
-- CREATE CONTEXT                           0
-- CREATE DATABASE                          0
-- CREATE DIMENSION                         0
-- CREATE DIRECTORY                         0
-- CREATE DISK GROUP                        0
-- CREATE ROLE                              0
-- CREATE ROLLBACK SEGMENT                  0
-- CREATE SEQUENCE                          0
-- CREATE MATERIALIZED VIEW                 0
-- CREATE MATERIALIZED VIEW LOG             0
-- CREATE SYNONYM                           0
-- CREATE TABLESPACE                        0
-- CREATE USER                              0
-- 
-- DROP TABLESPACE                          0
-- DROP DATABASE                            0
-- 
-- REDACTION POLICY                         0
-- 
-- ORDS DROP SCHEMA                         0
-- ORDS ENABLE SCHEMA                       0
-- ORDS ENABLE OBJECT                       0
-- 
-- ERRORS                                   0
-- WARNINGS                                 0
